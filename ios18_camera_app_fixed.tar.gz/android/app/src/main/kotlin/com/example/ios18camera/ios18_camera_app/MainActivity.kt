package com.example.ios18camera.ios18_camera_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
